#!/bin/bash
# Pricing Calculator - Zero-config setup
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${1:-pricing-demo}"

echo "🚀 Creating $PROJECT..."

# Create Vite project (suppress prompts)
npm create vite@latest "$PROJECT" -- --template react-ts --yes 2>/dev/null || \
npm create vite@latest "$PROJECT" -- --template react-ts

cd "$PROJECT"

# Install everything
echo "📦 Installing dependencies..."
npm install
npm install tailwindcss @tailwindcss/vite @radix-ui/react-label @radix-ui/react-select \
  @radix-ui/react-slider @radix-ui/react-slot @radix-ui/react-tooltip \
  class-variance-authority clsx tailwind-merge lucide-react

# Copy component
echo "📋 Setting up component..."
mkdir -p src/pricing-calculator-ultimate
cp -r "$SCRIPT_DIR"/PricingCalculator.tsx "$SCRIPT_DIR"/tokens.css \
      "$SCRIPT_DIR"/lib "$SCRIPT_DIR"/ui src/pricing-calculator-ultimate/

# Configure Vite
cat > vite.config.ts << 'VITE'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
})
VITE

# Setup CSS
cat > src/index.css << 'CSS'
@import "tailwindcss";
@import "./pricing-calculator-ultimate/tokens.css";

body { margin: 0; min-height: 100vh; }
#root { min-height: 100vh; }
CSS

# Setup App
cat > src/App.tsx << 'APP'
import { PricingCalculator } from './pricing-calculator-ultimate/PricingCalculator'

export default function App() {
  return (
    <div className="min-h-screen bg-page p-8">
      <div className="max-w-6xl mx-auto">
        <PricingCalculator
          commissionPercentage={15}
          onGenerateQuote={(_, b) => alert(`Total: $${b.total.toLocaleString()}/yr`)}
        />
      </div>
    </div>
  )
}
APP

# Cleanup
rm -f src/App.css

echo ""
echo "✅ Done! Run:"
echo "   cd $PROJECT && npm run dev"
